# E-Learning Platform Backend (Node.js)

Backend REST API untuk platform E-Learning dengan sistem role: **ADMIN**, **GURU**, **SISWA**.

## Tech Stack
- Node.js + Express.js
- PostgreSQL + Prisma ORM
- JWT Authentication
- bcryptjs (hash password)

## Cara Menjalankan

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy `.env.example` menjadi `.env` dan sesuaikan `DATABASE_URL` serta `JWT_SECRET`:
   ```bash
   cp .env.example .env
   ```

3. Jalankan migrasi database (membuat tabel dari schema.prisma):
   ```bash
   npx prisma migrate dev --name init
   ```

4. (Opsional) Isi data contoh — akun admin, guru, siswa, dan 1 kursus:
   ```bash
   npm run seed
   ```

5. Jalankan server:
   ```bash
   npm run dev
   ```

Server berjalan di `http://localhost:5000`.

## Akun Contoh (setelah seed)
| Role  | Email                | Password    |
|-------|-----------------------|-------------|
| Admin | admin@elearning.com  | password123 |
| Guru  | guru@elearning.com   | password123 |
| Siswa | siswa@elearning.com  | password123 |

## Daftar Endpoint

### Auth
| Method | Endpoint           | Akses   | Keterangan            |
|--------|---------------------|---------|------------------------|
| POST   | /api/auth/register  | Publik  | Daftar akun baru (SISWA/GURU) |
| POST   | /api/auth/login      | Publik  | Login, dapat token JWT |
| GET    | /api/auth/me         | Login   | Lihat profil sendiri   |

### Courses
| Method | Endpoint                     | Akses         | Keterangan               |
|--------|-------------------------------|---------------|----------------------------|
| GET    | /api/courses                  | Publik        | Daftar kursus              |
| GET    | /api/courses/:id               | Publik        | Detail kursus + materi     |
| POST   | /api/courses                   | GURU, ADMIN   | Buat kursus baru            |
| PUT    | /api/courses/:id                | Pemilik/ADMIN | Edit kursus                 |
| DELETE | /api/courses/:id                | Pemilik/ADMIN | Hapus kursus                |
| POST   | /api/courses/:id/enroll          | SISWA         | Daftar ke kursus            |
| POST   | /api/courses/:courseId/lessons  | Pemilik/ADMIN | Tambah materi ke kursus     |

### Lessons
| Method | Endpoint                | Akses         | Keterangan          |
|--------|---------------------------|---------------|------------------------|
| PUT    | /api/lessons/:id            | Pemilik/ADMIN | Edit materi            |
| DELETE | /api/lessons/:id            | Pemilik/ADMIN | Hapus materi            |
| POST   | /api/lessons/:id/complete    | SISWA         | Tandai materi selesai   |

### Users (Admin only, kecuali dashboard)
| Method | Endpoint                | Akses  | Keterangan                     |
|--------|---------------------------|--------|-----------------------------------|
| GET    | /api/users/me/dashboard     | Login  | Dashboard sesuai role yang login  |
| GET    | /api/users                  | ADMIN  | Daftar semua user                  |
| PATCH  | /api/users/:id/role          | ADMIN  | Ubah role user                     |
| DELETE | /api/users/:id               | ADMIN  | Hapus user                          |

## Contoh Request

**Register:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Ani","email":"ani@mail.com","password":"password123","role":"SISWA"}'
```

**Login:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ani@mail.com","password":"password123"}'
```

**Akses endpoint terproteksi** (gunakan token dari hasil login):
```bash
curl http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer <TOKEN_ANDA>"
```

## Struktur Folder
```
elearning-backend/
├── prisma/
│   ├── schema.prisma      # Model database
│   └── seed.js            # Data contoh
├── src/
│   ├── config/prisma.js   # Instance Prisma Client
│   ├── controllers/       # Logika bisnis tiap modul
│   ├── middleware/        # Auth & error handler
│   ├── routes/            # Definisi endpoint
│   ├── utils/             # JWT & response helper
│   ├── app.js             # Setup Express app
│   └── server.js          # Entry point
├── .env.example
└── package.json
```

## Catatan Integrasi dengan Frontend (Figma)
Backend ini dirancang generik agar cocok dipasangkan dengan frontend hasil desain Figma Make kamu.
Sesuaikan hal berikut dengan komponen di desainmu:
- Field pada form register/login (misal jika desain butuh `phone` atau `bio`, tambahkan ke schema `User`).
- Struktur response `data.course` / `data.user` bisa disesuaikan ke bentuk yang dipakai komponen React/Vue di desain.
- Tambahkan endpoint upload gambar (thumbnail kursus, avatar) dengan `multer` bila diperlukan — sudah ada di `package.json`.
