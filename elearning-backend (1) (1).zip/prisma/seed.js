const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const password = await bcrypt.hash('password123', 10);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@elearning.com' },
    update: {},
    create: { name: 'Admin Utama', email: 'admin@elearning.com', password, role: 'ADMIN' },
  });

  const guru = await prisma.user.upsert({
    where: { email: 'guru@elearning.com' },
    update: {},
    create: { name: 'Budi Santoso', email: 'guru@elearning.com', password, role: 'GURU' },
  });

  const siswa = await prisma.user.upsert({
    where: { email: 'siswa@elearning.com' },
    update: {},
    create: { name: 'Ani Wijaya', email: 'siswa@elearning.com', password, role: 'SISWA' },
  });

  const course = await prisma.course.upsert({
    where: { id: 'seed-course-1' },
    update: {},
    create: {
      id: 'seed-course-1',
      title: 'Belajar Node.js dari Nol',
      description: 'Kursus dasar Node.js untuk pemula, mencakup Express, database, dan REST API.',
      status: 'PUBLISHED',
      price: 0,
      instructorId: guru.id,
      lessons: {
        create: [
          { title: 'Pengenalan Node.js', order: 1, duration: 15 },
          { title: 'Membuat Server dengan Express', order: 2, duration: 25 },
          { title: 'Koneksi ke Database', order: 3, duration: 30 },
        ],
      },
    },
  });

  console.log('✅ Seed data berhasil dibuat:');
  console.log({ admin: admin.email, guru: guru.email, siswa: siswa.email, course: course.title });
  console.log('🔑 Semua akun menggunakan password: password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
