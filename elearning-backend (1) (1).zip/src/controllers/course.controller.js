const { validationResult } = require('express-validator');
const prisma = require('../config/prisma');
const { success, error } = require('../utils/response');

/**
 * GET /api/courses
 * Semua user bisa lihat daftar kursus yang PUBLISHED.
 * Guru bisa lihat kursus miliknya sendiri termasuk yang DRAFT.
 * Admin bisa lihat semua kursus.
 */
async function getAllCourses(req, res, next) {
  try {
    const { role, id: userId } = req.user || {};
    let where = { status: 'PUBLISHED' };

    if (role === 'ADMIN') {
      where = {};
    } else if (role === 'GURU') {
      where = { OR: [{ status: 'PUBLISHED' }, { instructorId: userId }] };
    }

    const courses = await prisma.course.findMany({
      where,
      include: {
        instructor: { select: { id: true, name: true, avatarUrl: true } },
        _count: { select: { lessons: true, enrollments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return success(res, 200, 'Berhasil mengambil daftar kursus.', { courses });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/courses/:id
 */
async function getCourseById(req, res, next) {
  try {
    const { id } = req.params;

    const course = await prisma.course.findUnique({
      where: { id },
      include: {
        instructor: { select: { id: true, name: true, avatarUrl: true } },
        lessons: { orderBy: { order: 'asc' } },
        _count: { select: { enrollments: true } },
      },
    });

    if (!course) {
      return error(res, 404, 'Kursus tidak ditemukan.');
    }

    return success(res, 200, 'Berhasil mengambil detail kursus.', { course });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/courses
 * Hanya GURU dan ADMIN yang boleh membuat kursus.
 */
async function createCourse(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return error(res, 400, 'Validasi gagal.', errors.array());
    }

    const { title, description, thumbnail, price } = req.body;

    const course = await prisma.course.create({
      data: {
        title,
        description,
        thumbnail,
        price: price || 0,
        instructorId: req.user.id,
      },
    });

    return success(res, 201, 'Kursus berhasil dibuat.', { course });
  } catch (err) {
    next(err);
  }
}

/**
 * PUT /api/courses/:id
 * Hanya pemilik kursus (GURU) atau ADMIN yang boleh mengedit.
 */
async function updateCourse(req, res, next) {
  try {
    const { id } = req.params;

    const course = await prisma.course.findUnique({ where: { id } });
    if (!course) {
      return error(res, 404, 'Kursus tidak ditemukan.');
    }

    const isOwner = course.instructorId === req.user.id;
    const isAdmin = req.user.role === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return error(res, 403, 'Anda tidak memiliki izin untuk mengedit kursus ini.');
    }

    const { title, description, thumbnail, price, status } = req.body;

    const updatedCourse = await prisma.course.update({
      where: { id },
      data: { title, description, thumbnail, price, status },
    });

    return success(res, 200, 'Kursus berhasil diperbarui.', { course: updatedCourse });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/courses/:id
 */
async function deleteCourse(req, res, next) {
  try {
    const { id } = req.params;

    const course = await prisma.course.findUnique({ where: { id } });
    if (!course) {
      return error(res, 404, 'Kursus tidak ditemukan.');
    }

    const isOwner = course.instructorId === req.user.id;
    const isAdmin = req.user.role === 'ADMIN';

    if (!isOwner && !isAdmin) {
      return error(res, 403, 'Anda tidak memiliki izin untuk menghapus kursus ini.');
    }

    await prisma.course.delete({ where: { id } });

    return success(res, 200, 'Kursus berhasil dihapus.');
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/courses/:id/enroll
 * Hanya SISWA yang bisa mendaftar ke kursus.
 */
async function enrollCourse(req, res, next) {
  try {
    const { id: courseId } = req.params;
    const studentId = req.user.id;

    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course || course.status !== 'PUBLISHED') {
      return error(res, 404, 'Kursus tidak ditemukan atau belum dipublikasikan.');
    }

    const existingEnrollment = await prisma.enrollment.findUnique({
      where: { studentId_courseId: { studentId, courseId } },
    });

    if (existingEnrollment) {
      return error(res, 409, 'Anda sudah terdaftar pada kursus ini.');
    }

    const enrollment = await prisma.enrollment.create({
      data: { studentId, courseId },
    });

    return success(res, 201, 'Berhasil mendaftar kursus.', { enrollment });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllCourses,
  getCourseById,
  createCourse,
  updateCourse,
  deleteCourse,
  enrollCourse,
};
