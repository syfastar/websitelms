const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');
const prisma = require('../config/prisma');
const { generateToken } = require('../utils/jwt');
const { success, error } = require('../utils/response');

/**
 * POST /api/auth/register
 * Daftar user baru. Role default: SISWA, kecuali diminta eksplisit (misal GURU).
 */
async function register(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return error(res, 400, 'Validasi gagal.', errors.array());
    }

    const { name, email, password, role } = req.body;

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return error(res, 409, 'Email sudah terdaftar.');
    }

    // Hanya izinkan role GURU atau SISWA saat registrasi publik.
    // Role ADMIN hanya bisa dibuat oleh admin lain (lihat user.controller.js).
    const allowedSelfRoles = ['SISWA', 'GURU'];
    const finalRole = allowedSelfRoles.includes(role) ? role : 'SISWA';

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: { name, email, password: hashedPassword, role: finalRole },
      select: { id: true, name: true, email: true, role: true, createdAt: true },
    });

    const token = generateToken({ id: user.id, role: user.role });

    return success(res, 201, 'Registrasi berhasil.', { user, token });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/login
 */
async function login(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return error(res, 400, 'Validasi gagal.', errors.array());
    }

    const { email, password } = req.body;

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return error(res, 401, 'Email atau password salah.');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return error(res, 401, 'Email atau password salah.');
    }

    const token = generateToken({ id: user.id, role: user.role });

    const { password: _, ...userWithoutPassword } = user;

    return success(res, 200, 'Login berhasil.', { user: userWithoutPassword, token });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/auth/me
 * Mengambil data profil user yang sedang login.
 */
async function getProfile(req, res, next) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatarUrl: true,
        createdAt: true,
      },
    });

    return success(res, 200, 'Berhasil mengambil profil.', { user });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, getProfile };
