const { validationResult } = require('express-validator');
const prisma = require('../config/prisma');
const { success, error } = require('../utils/response');

/**
 * POST /api/courses/:courseId/lessons
 * Hanya pemilik kursus (GURU) atau ADMIN yang boleh menambah materi.
 */
async function createLesson(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return error(res, 400, 'Validasi gagal.', errors.array());
    }

    const { courseId } = req.params;
    const { title, content, videoUrl, order, duration } = req.body;

    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course) {
      return error(res, 404, 'Kursus tidak ditemukan.');
    }

    const isOwner = course.instructorId === req.user.id;
    const isAdmin = req.user.role === 'ADMIN';
    if (!isOwner && !isAdmin) {
      return error(res, 403, 'Anda tidak memiliki izin untuk menambah materi pada kursus ini.');
    }

    const lesson = await prisma.lesson.create({
      data: { title, content, videoUrl, order: order || 0, duration, courseId },
    });

    return success(res, 201, 'Materi berhasil ditambahkan.', { lesson });
  } catch (err) {
    next(err);
  }
}

/**
 * PUT /api/lessons/:id
 */
async function updateLesson(req, res, next) {
  try {
    const { id } = req.params;

    const lesson = await prisma.lesson.findUnique({
      where: { id },
      include: { course: true },
    });

    if (!lesson) {
      return error(res, 404, 'Materi tidak ditemukan.');
    }

    const isOwner = lesson.course.instructorId === req.user.id;
    const isAdmin = req.user.role === 'ADMIN';
    if (!isOwner && !isAdmin) {
      return error(res, 403, 'Anda tidak memiliki izin untuk mengedit materi ini.');
    }

    const { title, content, videoUrl, order, duration } = req.body;

    const updatedLesson = await prisma.lesson.update({
      where: { id },
      data: { title, content, videoUrl, order, duration },
    });

    return success(res, 200, 'Materi berhasil diperbarui.', { lesson: updatedLesson });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/lessons/:id
 */
async function deleteLesson(req, res, next) {
  try {
    const { id } = req.params;

    const lesson = await prisma.lesson.findUnique({
      where: { id },
      include: { course: true },
    });

    if (!lesson) {
      return error(res, 404, 'Materi tidak ditemukan.');
    }

    const isOwner = lesson.course.instructorId === req.user.id;
    const isAdmin = req.user.role === 'ADMIN';
    if (!isOwner && !isAdmin) {
      return error(res, 403, 'Anda tidak memiliki izin untuk menghapus materi ini.');
    }

    await prisma.lesson.delete({ where: { id } });

    return success(res, 200, 'Materi berhasil dihapus.');
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/lessons/:id/complete
 * Siswa menandai materi sebagai selesai dipelajari.
 */
async function markLessonComplete(req, res, next) {
  try {
    const { id: lessonId } = req.params;
    const studentId = req.user.id;

    const lesson = await prisma.lesson.findUnique({ where: { id: lessonId } });
    if (!lesson) {
      return error(res, 404, 'Materi tidak ditemukan.');
    }

    // Pastikan siswa terdaftar pada kursus terkait
    const enrollment = await prisma.enrollment.findUnique({
      where: { studentId_courseId: { studentId, courseId: lesson.courseId } },
    });
    if (!enrollment) {
      return error(res, 403, 'Anda belum terdaftar pada kursus ini.');
    }

    const progress = await prisma.lessonProgress.upsert({
      where: { studentId_lessonId: { studentId, lessonId } },
      update: { isCompleted: true, completedAt: new Date() },
      create: { studentId, lessonId, isCompleted: true, completedAt: new Date() },
    });

    return success(res, 200, 'Materi ditandai selesai.', { progress });
  } catch (err) {
    next(err);
  }
}

module.exports = { createLesson, updateLesson, deleteLesson, markLessonComplete };
