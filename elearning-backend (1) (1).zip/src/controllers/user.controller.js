const bcrypt = require('bcryptjs');
const prisma = require('../config/prisma');
const { success, error } = require('../utils/response');

/**
 * GET /api/users
 * Hanya ADMIN yang bisa melihat semua user.
 */
async function getAllUsers(req, res, next) {
  try {
    const { role } = req.query;

    const users = await prisma.user.findMany({
      where: role ? { role } : undefined,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatarUrl: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return success(res, 200, 'Berhasil mengambil daftar user.', { users });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/users/:id/role
 * Hanya ADMIN yang bisa mengubah role user (misal promosikan siswa jadi guru).
 */
async function updateUserRole(req, res, next) {
  try {
    const { id } = req.params;
    const { role } = req.body;

    const validRoles = ['ADMIN', 'GURU', 'SISWA'];
    if (!validRoles.includes(role)) {
      return error(res, 400, `Role tidak valid. Pilih salah satu: ${validRoles.join(', ')}`);
    }

    const user = await prisma.user.update({
      where: { id },
      data: { role },
      select: { id: true, name: true, email: true, role: true },
    });

    return success(res, 200, 'Role user berhasil diperbarui.', { user });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/users/:id
 * Hanya ADMIN yang bisa menghapus user.
 */
async function deleteUser(req, res, next) {
  try {
    const { id } = req.params;

    if (id === req.user.id) {
      return error(res, 400, 'Anda tidak bisa menghapus akun Anda sendiri.');
    }

    await prisma.user.delete({ where: { id } });

    return success(res, 200, 'User berhasil dihapus.');
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/users/me/dashboard
 * Dashboard ringkas sesuai role yang sedang login.
 */
async function getMyDashboard(req, res, next) {
  try {
    const { id, role } = req.user;

    if (role === 'SISWA') {
      const enrollments = await prisma.enrollment.findMany({
        where: { studentId: id },
        include: {
          course: {
            include: { instructor: { select: { name: true } }, _count: { select: { lessons: true } } },
          },
        },
      });
      return success(res, 200, 'Dashboard siswa.', { enrollments });
    }

    if (role === 'GURU') {
      const courses = await prisma.course.findMany({
        where: { instructorId: id },
        include: { _count: { select: { lessons: true, enrollments: true } } },
      });
      return success(res, 200, 'Dashboard guru.', { courses });
    }

    // ADMIN
    const [totalUsers, totalCourses, totalEnrollments] = await Promise.all([
      prisma.user.count(),
      prisma.course.count(),
      prisma.enrollment.count(),
    ]);
    return success(res, 200, 'Dashboard admin.', {
      stats: { totalUsers, totalCourses, totalEnrollments },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getAllUsers, updateUserRole, deleteUser, getMyDashboard };
