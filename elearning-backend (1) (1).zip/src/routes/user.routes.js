const express = require('express');
const {
  getAllUsers,
  updateUserRole,
  deleteUser,
  getMyDashboard,
} = require('../controllers/user.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

const router = express.Router();

router.get('/me/dashboard', authenticate, getMyDashboard);

// Hanya ADMIN yang boleh mengelola user
router.get('/', authenticate, authorize('ADMIN'), getAllUsers);
router.patch('/:id/role', authenticate, authorize('ADMIN'), updateUserRole);
router.delete('/:id', authenticate, authorize('ADMIN'), deleteUser);

module.exports = router;
