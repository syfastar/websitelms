const express = require('express');
const {
  updateLesson,
  deleteLesson,
  markLessonComplete,
} = require('../controllers/lesson.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

const router = express.Router();

router.put('/:id', authenticate, authorize('GURU', 'ADMIN'), updateLesson);
router.delete('/:id', authenticate, authorize('GURU', 'ADMIN'), deleteLesson);
router.post('/:id/complete', authenticate, authorize('SISWA'), markLessonComplete);

module.exports = router;
