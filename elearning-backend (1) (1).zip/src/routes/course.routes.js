const express = require('express');
const { body } = require('express-validator');
const {
  getAllCourses,
  getCourseById,
  createCourse,
  updateCourse,
  deleteCourse,
  enrollCourse,
} = require('../controllers/course.controller');
const { createLesson } = require('../controllers/lesson.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

const router = express.Router();

// Publik / opsional auth (daftar & detail kursus bisa dilihat semua orang)
router.get('/', getAllCourses);
router.get('/:id', getCourseById);

// Hanya GURU dan ADMIN yang bisa membuat kursus
router.post(
  '/',
  authenticate,
  authorize('GURU', 'ADMIN'),
  [
    body('title').trim().notEmpty().withMessage('Judul kursus wajib diisi.'),
    body('description').trim().notEmpty().withMessage('Deskripsi wajib diisi.'),
  ],
  createCourse
);

router.put('/:id', authenticate, authorize('GURU', 'ADMIN'), updateCourse);
router.delete('/:id', authenticate, authorize('GURU', 'ADMIN'), deleteCourse);

// Hanya SISWA yang bisa mendaftar kursus
router.post('/:id/enroll', authenticate, authorize('SISWA'), enrollCourse);

// Tambah materi ke kursus (nested route)
router.post(
  '/:courseId/lessons',
  authenticate,
  authorize('GURU', 'ADMIN'),
  [body('title').trim().notEmpty().withMessage('Judul materi wajib diisi.')],
  createLesson
);

module.exports = router;
