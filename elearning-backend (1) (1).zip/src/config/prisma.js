const { PrismaClient } = require('@prisma/client');

// Gunakan satu instance PrismaClient di seluruh aplikasi (singleton)
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
});

module.exports = prisma;
