const { error } = require('../utils/response');

function notFound(req, res, next) {
  error(res, 404, `Endpoint tidak ditemukan: ${req.method} ${req.originalUrl}`);
}

function errorHandler(err, req, res, next) {
  console.error(err.stack);

  // Prisma unique constraint error
  if (err.code === 'P2002') {
    return error(res, 409, `Data dengan ${err.meta?.target?.join(', ')} sudah terdaftar.`);
  }

  // Prisma record not found
  if (err.code === 'P2025') {
    return error(res, 404, 'Data tidak ditemukan.');
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Terjadi kesalahan pada server.';

  error(res, statusCode, message);
}

module.exports = { notFound, errorHandler };
