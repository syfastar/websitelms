const { verifyToken } = require('../utils/jwt');
const { error } = require('../utils/response');
const prisma = require('../config/prisma');

/**
 * Middleware untuk memverifikasi token JWT dan melampirkan data user ke req.user
 */
async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return error(res, 401, 'Token tidak ditemukan. Silakan login terlebih dahulu.');
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    // Pastikan user masih ada di database
    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: { id: true, name: true, email: true, role: true },
    });

    if (!user) {
      return error(res, 401, 'User tidak ditemukan.');
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return error(res, 401, 'Token telah kadaluarsa. Silakan login kembali.');
    }
    return error(res, 401, 'Token tidak valid.');
  }
}

/**
 * Middleware untuk membatasi akses berdasarkan role.
 * Contoh penggunaan: authorize('ADMIN', 'GURU')
 */
function authorize(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return error(res, 401, 'Belum terautentikasi.');
    }

    if (!allowedRoles.includes(req.user.role)) {
      return error(
        res,
        403,
        `Akses ditolak. Role '${req.user.role}' tidak memiliki izin untuk aksi ini.`
      );
    }

    next();
  };
}

module.exports = { authenticate, authorize };
